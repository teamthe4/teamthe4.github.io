<!DOCTYPE html>
<html lang="ar">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="google-site-verification" content="vv0wD_A72Bk7q7hpEqmhoU_1dkwrvhkwCEaSl8T9e3E" />
	<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-139598377-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-139598377-1');
</script>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-MRV4KN2');</script>
<!-- End Google Tag Manager -->
	<!--SEO META TAGS-->
	<title>فريق الأربعة - خدمات الإتصالات وتقنية المعلومات - تصميم وبرمجة مواقع الويب وتطبيقات الموبايل وقواعد البيانات وبرامج سطح المكتب</title>
    <meta name='description' content='خدمات الإتصالات وتقنية المعلومات - تصميم وبرمجة مواقع الويب وتطبيقات الموبايل وقواعد البيانات وبرامج سطح المكتب'>
    <meta name='keywords' content='فريق الأربعة , تكنولوجيا المعلومات , الإتصالات, تقنية المعلومات, خدمات الويب,تصميم ,برمجة , تطبيقات جوال,مواقع ويب ,حلول برمجية'>	
		
	<!--FACEBOOK META TAGS-->
	<meta property="og:url"           content="http://teamthe4.com/404.php" />
	<meta property="og:type"          content="website" />
	<meta property="og:title"         content="لوحة الادارة رائعة مع ميزات رهيبة" />
	<meta property="og:description"   content="خدمات الإتصالات وتقنية المعلومات - تصميم وبرمجة مواقع الويب وتطبيقات الموبايل وقواعد البيانات وبرامج سطح المكتب" />
	<meta property="og:image"         content='/assets/img/uploads/other/122bf9f5704b4f61e894c083808f13da.jpg' />
	
	<link rel="shortcut icon" href="assets/img/tt4-favicon-icon.ico" type="image/x-icon" >
	
    <!-- Bootstrap Core CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
<!-- styles-rtl.css 
<link href="assets/css/bootstrap-rtl.min.css" rel="stylesheet">-->
	
    <!-- Custom Fonts -->
    <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="assets/font-awesome/css/brands.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
	<link href="assets/fonts/GE_Dinar_Two_Medium/stylesheet.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="assets/css/owl.carousel.min.css">
	<link rel="stylesheet" href="assets/css/owl.theme.default.css">
	<link rel="stylesheet" href="assets/css/animate.css">
	
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
   
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	<script src="admin/assets/js/sweetalert.min.js"></script> 
	<link rel="stylesheet" type="text/css" href="admin/assets/css/sweetalert.css">
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>

	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script>window.jQuery || document.write('<script src="../libs/jquery/dist/jquery.min.js"><\/script>')</script>
	<script src="admin/assets/js/jquery.vide.js"></script>
	
	<link rel="stylesheet" type="text/css" href="assets/css/jquery.fancybox.css">
	
	<!-- cookie RGPD 
	<link rel="stylesheet" type="text/css" href="assets/css/jquery-eu-cookie-law-popup.css"/>
	<script src="assets/js/jquery-eu-cookie-law-popup.js"></script>-->
	
	<link href="admin/assets/css/dataTables.bootstrap.css" rel="stylesheet">
	
	<!-- Custom CSS -->
    <link href="assets/css/styles.css" rel="stylesheet">
	<!-- Custom CSS 
	<link href="assets/css/styles-rtl.css" rel="stylesheet">-->
	
	<!-- Flags Languages CSS -->
	<link rel='stylesheet prefetch' href='assets/flag-icon-css/css/flag-icon.min.css'>

	
	<script>
		jQuery(window).load(function() {
			jQuery("#loading-center").delay(800).fadeOut(800);
			jQuery("#loading").delay(800).fadeOut(800);
		});
		 
	</script>
	
	
	<link href='https://fonts.googleapis.com/css?family=Cairo' rel='stylesheet'>	
	<!-- Custom CSS Area -->
	<style>
	
	
	/* Tablet Landscape */
@media only screen and (min-width: 958px) and (max-width: 1079px) {
}

/* Tablet Portrait size to standard 960 (devices and browsers) */
@media only screen and (min-width: 768px) and (max-width: 959px) {
}

/* Mobile Landscape Size to Tablet Portrait (devices and browsers) */
@media only screen and (min-width: 480px) and (max-width: 767px) {
}

/* Vertical Iphone */
@media only screen and (max-width: 479px) {
}

	
		body {font-family: 'Cairo' !important;}
		.text-vertical-center h1 {color: #4440e3;}
		.text-vertical-center h3 {color: #4440e3;}
		#breadcrumbs {
			background-color:#13bcb9;
		}
		.footer-bs {
			background-color:rgba(0,0,0,0.8);
		}
			
		/* Tablet Landscape */
		@media only screen and (min-width: 958px) and (max-width: 1079px) {

		}

		@media only screen and (min-width: 958px) and (max-width: 1024px) {

		}

		/* Tablet Portrait size to standard 960 (devices and browsers) */
		@media only screen and (min-width: 768px) and (max-width: 959px) {
			
		}

		/* Mobile Landscape Size to Tablet Portrait (devices and browsers) */
		@media only screen and (min-width: 480px) and (max-width: 767px) {
			.Modern-Slider {
				margin-top: 120px; !important;
			}
			.Modern-Slider .item .img-fill {
				height: 275px !important;
			}
			.Modern-Slider .item h3 {
				font: 22px/22px 'Cairo' !important;
				padding-bottom: 10px !important;
			}
			.Modern-Slider .item h5 {
				font: 15px/15px 'Cairo' !important;
				height: 135px !important;
				text-transform: initial !important;
			}
			.Modern-Slider .item .img-fill .info {
				line-height: 94vh !important;
				padding: 0 8%;
			}
		}
		
		@media only screen and (max-width: 479px) {
			.Modern-Slider .item h3 {
				font: 22px/22px 'Cairo' !important;
				padding-bottom: 10px !important;
			}
			.Modern-Slider .item h5 {
				font: 15px/15px 'Cairo' !important;
				height: 135px !important;
				text-transform: initial !important;
			}
			.Modern-Slider .item .img-fill .info {
				line-height: 60vh !important;
				padding: 0 15%;
			}
			.Modern-Slider {
				margin-top: 130px !important;
			}
		}		
			
			.countdown-section {
				border-radius: 50% 50%;
				-webkit-border-radius: 50% 50%;
				-moz-border-radius: 50% 50%;
				border:solid 5px #13bcb9;				
			}
			.countdown-period {
				color:#ffffff;
				font-size:20px;
				margin-top: -20px;
			}
			#defaultCountdown{
				color: #ffffff;
				
			}	
	 	
	
	 	
	 	
	
			.progress {
				height: 50px;
			}
			.progress-bar{
				line-height:50px;
				background-color: rgba(255,199,0,0.99);
			}	
		
			.member-details > div:after {
				background-image: linear-gradient(45deg, #13bcb9 50%, transparent 50%);
			}
			.portfolio-section figure .inner-overlay-content.with-icons a{
				background-color: #13bcb9;
			}
			.action:hover, .action:focus {
				color: #098039;
			}
			.parallax-window {
				background-color: rgba(0, 0, 0, 0.6);
			}
			#sidebar-wrapper {
				background: #098039;
			}
			.sidebar-nav li a {
				color: #ffffff;
			}
			.bg-primary {
				color: #f70833;
				background-color: #13bcb9;
			}
			.btn-dark {
				color: #4440e3;
				background-color: #403d3e;
			}
			.btn-dark:hover, .btn-dark:focus, .btn-dark:active {
				color: rgba(235,255,0,0.99);
				background-color: #137d7b;
			}
			.btn-light{
				color: #4440e3;
				background-color: #403d3e;
			}
			.btn-light:hover, .btn-light:focus, .btn-light:active {
				color: rgba(235,255,0,0.99);
				background-color: #137d7b;
			}
			.text-primary {
				color: #13bcb9;
			}
			footer a {
				color: #13bcb9;
			}
			footer a:focus, a:hover {
				color: #137d7b;
				text-decoration: none;
			}
			.testimonial-name {
				background: #13bcb9;
			}
			.btn-primary {
				color: #fff;
				background-color: #137d7b;
				border-color:  #137d7b;
			}
			.btn-primary.disabled:hover{
				color: #fff;
				background-color: #403d3e;
				border-color:  #137d7b;
			}
			.btn-primary:hover {
				color: #fff;
				background-color: #403d3e;
				border-color:  #137d7b;
			}
			.btn-primary:active:focus, .btn-primary:active:hover{
				color: #fff;
				background-color: #403d3e;
				border-color:  #137d7b;
			}			
			input:-webkit-autofill {
				-webkit-box-shadow: 0 0 0 1000px #13bcb9 inset !important;
				-webkit-text-fill-color:#f70833;
			}
			.input__field--hoshi {
				color: #f70833 !important;
			}
			.blog .post-bg:hover .hover-post {
				background-color: #13bcb9;
			}
			ul.filter > li > a {
				color: #403d3e;
			}
			ul.filter > li > a:hover, ul.filter > li > a:focus {
				color: #13bcb9;
			}
			.blog .post-bg:hover h3 {
				color: #403d3e;
			}
			.input__label--hoshi-color-1::after {
				border-color: #13bcb9;
			}
			#breadcrumbs a {
				color: #403d3e;
			}
			.portfolio-section figure .overlay-background .inner {
				background-color: #13bcb9; 
			}
			.hover-post {
				background-color: #13bcb9;
			}
			.Modern-Slider .slick-dots li {
				background-color: #13bcb9;
			}
			.Modern-Slider .item h3 {
				font: 50px/45px 'Cairo';
				text-transform: uppercase;
				max-width: 800px;
			}
			.Modern-Slider .item h5 {
				font: 15px/20px 'Cairo';
				text-transform: uppercase;
				height: 80px;
				max-width: 800px;
			}
			.pricing-74 .pricing-panel-4 .btn:hover {
				background-color: #13bcb9;
				border-color: #13bcb9;
			}
			.pricing-74 .pricing-panel-4 .pricing--body .pricing--list li i {
				color: #13bcb9;
			}
			.text_s {
				background-color: #13bcb9;
			}
			.text_s a{
				color: #fff;
			}
			.object{
				background-color: #13bcb9;
			}
			.sk-chasing-dots .sk-child {
				background-color: #13bcb9;
			}
			.sk-rotating-plane {
				background-color: #13bcb9;
			}
			.sk-double-bounce .sk-child {
				background-color: #13bcb9;
			}
			.sk-wave .sk-rect {
				background-color: #13bcb9;
			}
			.sk-wandering-cubes .sk-cube {
				background-color: #13bcb9;
			}
			.sk-spinner-pulse {
				background-color: #13bcb9;
			}
			.sk-three-bounce .sk-child {
				background-color: #13bcb9;
			}
			.sk-circle .sk-child:before {
				background-color: #13bcb9;
			}
			.sk-cube-grid .sk-cube {
				background-color: #13bcb9;
			}
			.sk-fading-circle .sk-circle:before {
				background-color: #13bcb9;
			}
			.sk-folding-cube .sk-cube:before {
				background-color: #13bcb9;
			}
				
		
		
		
		
		
	
			#partners {
			background: none !important;
		}
		
	
			.blog h2 {
			color: #fff;
		}
		
	
			.testimonials h2 {
			color: #fff;
		}
		
	
			.header {
				background: none;
				-webkit-background-size: cover;
				-moz-background-size: cover;
				background-size: cover;
				-o-background-size: cover;
			}
			#resizeSlider {
				position: absolute !important;
			}
			#home h1, #home h3 {
				color: #fff;
			}
			
	

		 
	
				nav.navbar.navbar-custom.navbar-fixed-top {
					display: none;
				}

				#sidebar-wrapper {
					display:none;
				}

				#sidebar-wrapper.active {
					display:none;
				}
				.navbar{
					display:none;
				}
				#menu-toggle {
					display:none;
				}	
				
			
				.cd-primary-nav {
					background: #13bcb9 !important;
				}
				.cd-secondary-nav {
					background-color: #098039 !important;
				}
				.navbar-toggle {
					background-color: #13bcb9 !important;
				}
				.navbar-toggle .icon-bar {
					background-color: #098039 !important;
				}
				/* Tablet Landscape */
				@media only screen and (min-width: 1080px) {
					.navbar-brand img {
						margin-top: 0px;
					}
					.navbar-nav>li>a {
						padding-top: 10px;
						padding-bottom: 10px;
						line-height: 35px !important;
					}
					.cd-secondary-nav .nav>li>a {
						position: relative;
						display: block;
						padding: 10px 10px !important;
					}
				}
				
				/* Tablet Landscape */
				@media only screen and (min-width: 958px) and (max-width: 1079px) {
					.navbar-nav>li>a {
						line-height: 0px !important;
					}

				}

				@media only screen and (min-width: 958px) and (max-width: 1024px) {
					.navbar-brand {
						float: initial;
					}
					.inner {
						padding-top: 20%;
					}	
					.cd-secondary-nav {
						height: 55px;
					}
				}

				/* Tablet Portrait size to standard 960 (devices and browsers) */
				@media only screen and (min-width: 768px) and (max-width: 959px) {
					.inner {
						padding-top: 20%;
					}

				}

				/* Mobile Landscape Size to Tablet Portrait (devices and browsers) */
				@media only screen and (min-width: 480px) and (max-width: 767px) {
					.navbar-brand {
						float: initial;
					}
					.inner {
						padding-top: 30%;
					}
					.cd-secondary-nav {
						height: 75px;
					}
					.navbar-brand img {
						margin-top: -5px;
					}
				}
				@media only screen and (max-width: 479px) {
					.inner {
						padding-top: 50%;
					}
					.cd-secondary-nav {
						height: 100%;
					}
				}
					
	
	</style>
	<style>
@media only screen and (max-width: 767px) and (min-width: 480px)
{
#dropdown09 {    display: contents;
}
}
@media only screen and (max-width: 479px)
{
#dropdown09 {    display: contents;	
}
}
.ul-lang 
{
	padding: 0px; 
	display: block;
}
.fa {
font-family: 'Cairo' , 'FontAwesome','FontAwesome5Brands';
}
.help-block.with-errors> .list-unstyled {padding: 0px;color:red;}
.rowflex {
  display: -webkit-box;
  display: -webkit-flex;
  display: -ms-flexbox;
  display:         flex;
  flex-wrap: wrap;
}
.rowrowflex > [class*='col-'] {
display: flex;
flex-direction: column;

}

.features {
background: #f9f0f0;
text-align: center;
color: black;
}

.tt4_ar_ge{
font-family:'tt4_ar_ge_dinar';
}
.service-item {
    margin-bottom: 40px;
}
.service-item>.img-thumbnail {
max-height: 250px;
min-height: 250px;
}
.service-item>.middle {
top: 32%;
}
.service-item>.bottom {
bottom: 0;
position: absolute;
right: 10%;
left: 10%;
}
.service-item>.bottomindx {
    bottom: 0;
    position: absolute;
    right: 5%;
    left: 5%;
}
#breadcrumbs p {
   font-size: large;
   text-align: center;
}

section#aboutfront a{
/*color: #fff;*/
}
.o_icon {
    display: block;
    width: 100%;
}
.o_icon:before {
    display: block;
    content: "";
    width: 100%;
    padding-top: 13%;
    background-size: 100% auto;
    background-repeat: no-repeat;
    background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxNjMiIGhlaWdodD0iMjEiIHZpZXdCb3g9IjY3IDAgMTYzIDIxIj48c3R5bGUgdHlwZT0idGV4dC9jc3MiPi5he2ZpbGw6I0ZGRn08L3N0eWxlPjxwYXRoIGNsYXNzPSJhIiBkPSJNMTM2LjYsMTMuMWgxMC4ybC01LjQtOC43bC05LjksMTUuN0gxMjdsMTItMTguOWMwLjUtMC44LDEuNC0xLjIsMi40LTEuMmMwLjksMCwxLjgsMC40LDIuMywxLjJsMTIuMSwxOC45IGgtNC41bC0yLjEtMy41aC0xMC4zTDEzNi42LDEzLjEiLz48cGF0aCBjbGFzcz0iYSIgZD0iTTE4My40LDE2LjVWMC4yaC0zLjh2MThjMCwwLjUsMC4yLDEsMC42LDEuM2MwLjQsMC40LDAuOSwwLjYsMS40LDAuNmgxNy40bDIuMy0zLjVMMTgzLjQsMTYuNSIvPjxwYXRoIGNsYXNzPSJhIiBkPSJNMTIwLjIsMTMuNmMzLjcsMCw2LjctMyw2LjctNi43YzAtMy43LTMtNi43LTYuNy02LjdoLTE2Ljd2MTkuOWgzLjhWMy43aDEyLjZjMS44LDAsMy4yLDEuNCwzLjIsMy4yIGMwLDEuOC0xLjQsMy4yLTMuMiwzLjJsLTEwLjgsMGwxMS40LDEwaDUuNWwtNy43LTYuNEwxMjAuMiwxMy42Ii8+PHBhdGggY2xhc3M9ImEiIGQ9Ik03OS45LDIwLjFjLTUuNSwwLTkuOS00LjQtOS45LTkuOWMwLTUuNSw0LjQtOS45LDkuOS05LjloMTEuNWM1LjUsMCw5LjksNC40LDkuOSw5LjljMCw1LjUtNC40LDkuOS05LjksOS45SDc5LjkgTTkxLjIsMTYuNmMzLjYsMCw2LjQtMi45LDYuNC02LjRjMC0zLjYtMi45LTYuNC02LjQtNi40aC0xMWMtMy41LDAtNi40LDIuOS02LjQsNi40czIuOSw2LjQsNi40LDYuNEg5MS4yIi8+PHBhdGggY2xhc3M9ImEiIGQ9Ik0xNjMuOCwyMC4xYy01LjUsMC0xMC00LjQtMTAtOS45YzAtNS41LDQuNS05LjksMTAtOS45aDEzLjdsLTIuMywzLjVIMTY0Yy0zLjYsMC02LjUsMi45LTYuNSw2LjRjMCwzLjUsMi45LDYuNCw2LjUsNi40aDEzLjhsLTIuMiwzLjVIMTYzLjgiLz48cGF0aCBjbGFzcz0iYSIgZD0iTTIxMC41LDE2LjZjLTIuOSwwLTUuNC0yLTYuMi00LjdoMTYuNGwyLjItMy41aC0xOC42YzAuOC0yLjcsMy4zLTQuNyw2LjItNC43aDExLjJsMi4yLTMuNWgtMTMuN2MtNS41LDAtOS45LDQuNC05LjksOS45YzAsNS41LDQuNCw5LjksOS45LDkuOUgyMjJsMi4yLTMuNUgyMTAuNSIvPjxwYXRoIGNsYXNzPSJhIiBkPSJNMjI2LDIuM2MwLTEsMC44LTEuOCwxLjgtMS44YzEsMCwxLjgsMC44LDEuOCwxLjhjMCwxLTAuOCwxLjgtMS44LDEuOEMyMjYuOCw0LjEsMjI2LDMuMywyMjYsMi4zIE0yMjcuOCw0LjZjMS4yLDAsMi4yLTEsMi4yLTIuMmMwLTEuMi0xLTIuMi0yLjItMi4yYy0xLjIsMC0yLjIsMS0yLjIsMi4yUzIyNi41LDQuNiwyMjcuOCw0LjYgTTIyNy42LDFjMC4zLDAsMC41LDAsMC42LDAuMWMwLjUsMC4xLDAuNSwwLjYsMC41LDAuN2MwLDAsMCwwLjEsMCwwLjJjMCwwLjEtMC4xLDAuMy0wLjMsMC40YzAsMCwwLDAtMC4xLDAuMWwwLjYsMWgtMC42bC0wLjUtMWgtMC4zdjFIMjI3VjFIMjI3LjYgTTIyNy43LDIuMWMwLjIsMCwwLjMsMCwwLjQtMC4yYzAuMSwwLDAuMS0wLjEsMC4xLTAuMmMwLTAuMS0wLjEtMC4yLTAuMi0wLjNjLTAuMS0wLjEtMC4yLTAuMS0wLjUtMC4xaC0wLjF2MC43SDIyNy43Ii8+PC9zdmc+);
    opacity: 1;
}

#loading-center-1{position: unset;}
.stats {font-family: "cairo", sans-serif;}
.noparallax{background-color: rgba(0, 0, 0, 0.6);} 

ul.filter > li.active a {
    font-weight: bold;
    color: red;
}
.portfolio-section .article-title a {
    color: red;
}
.features li i {float: left;} .features {
padding: 15px 7%;} .features li { padding: 5px 0;text-align: right;}#services,#aboutfront,#team,#counter-stats,#pricing,#subscribe,#the-end,#about,#contact,#portfolio {direction:rtl;} .input__label--hoshi{text-align:center ;} .team> [class*="col-"] {float:right;} #counter> [class*="col-"] {float:right;} .clients> form [class*="col-"] {float:right;}
</style>
</head>

<body class="eupopup eupopup-bottomleft" >

<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MRV4KN2"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

 <a id="top" style="visibility:hidden;" class="page-scroll"></a>
 
	
<!-- Preloader -->
<div id='loading' class='text-center'>
<div style='display: inline-block;'>
 <img id='besm' src='r9se.gif' class='img-responsive  image'><br><img  class='img-responsive' src='img-x/tt4-in-the-name-of-allah.gif'></div>
					
				<div id='loading-center-1' >
					<div class='sk-chasing-dots'>
						<div class='sk-child sk-dot1'></div>
						<div class='sk-child sk-dot2'></div>
					  </div>
					  
				</div>		
			</div>	

	
<header class="cd-auto-hide-header">
<nav class="cd-primary-nav">
<div class="col-md-6 contact-top">

 

<div class='list'>
<i class='fa fa-envelope'></i> <a href="/cdn-cgi/l/email-protection#c5acaba3aa85b1a0a4a8b1ada0f1eba6aaa8"><span class="__cf_email__" data-cfemail="61080f070e211504000c150904554f020e0c">[email&#160;protected]</span></a>
</div>
<div class='list'>
<i class='fa fa-phone'></i> +966 ( 0563720102 - 0548633511 )						
</div>
</div>
<div class="col-md-6 social-top">
<ul>
<li><a href='https://www.facebook.com/' target='_blank'> <i class='fa fa-facebook' aria-hidden='true'></i></a></li><li><a href='#' target='_blank'> <i class='fa fa-twitter' aria-hidden='true'></i> </a></li><li><a href='#' target='_blank'> <i class='fa fa-linkedin' aria-hidden='true'></i></a></li><li><a href='#' target='_blank'> <i class='fa fa-google-plus' aria-hidden='true'></i></a></li><li><a href='#' target='_blank'> <i class='fa fa-youtube' aria-hidden='true'></i> </a></li>				
</ul>
</div>
</nav>
 <!-- end .cd-primary-nav -->
<nav class="cd-secondary-nav">
<div class="container">
<div class="navbar-header col-md-4">
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
TT4 <i class="fa fa-bars"></i>
</button>

<a class='navbar-brand page-scroll' href='./'>
<img src ='assets/img/uploads/other/teamthe4-logo.jpg' class='img-responsive'  style='height:-webkit-fill-available; border-radius: 7px;' />
</a>              
</div>

<!-- Collect the nav links, forms, and other content for toggling -->
<div class="collapse navbar-collapse col-md-8 navbar-right navbar-main-collapse">
<ul class="nav navbar-nav">
<!-- Hidden li included to remove active class from about link when scrolled up past about section -->
<li class="hidden">
<a href="./"></a>
</li>
<li class="dropdown li-lang">
<a class="dropdown-toggle" href="#" id="dropdown09" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="flag-icon flag-icon-sa"> </span> Arabic</a>
<div class="dropdown-menu" aria-labelledby="dropdown09" style="min-width: auto;">
<ul class="ul-lang" style="display: block;padding: 0px;" ><li><a class="dropdown-item" href="changelanguage.php?language=English" style="line-height: inherit;padding: 3px;white-space: nowrap;" ><span class="flag-icon flag-icon-us"> </span> English</a></li><li><a class="dropdown-item" href="changelanguage.php?language=French" style="line-height: inherit;padding: 3px;white-space: nowrap;" ><span class="flag-icon flag-icon-fr"> </span> French</a></li></ul></div></li>
 
<li>
<a href='about'>إعرفنا</a>
</li> 
<li>
<a href='services'>خدمات</a>
</li> 
<li>
<a href='portfolio'>أعمالنا</a>
</li> 
<li>
<a href='contacts'>إتصل</a>
</li>
</ul>
</div>
<!-- /.navbar-collapse -->
</div>		
</nav> <!-- .cd-secondary-nav -->
</header> <!-- .cd-auto-hide-header -->


<!-- Navigation -->
<nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
<div class="container">
<div class="navbar-header col-md-4">
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
Menu <i class="fa fa-bars"></i>
</button>

<a class='navbar-brand page-scroll' href='./'>
<img src ='assets/img/uploads/other/teamthe4-logo.jpg' class='img-responsive' style='height:-webkit-fill-available; border-radius: 7px;' />
</a>              
</div>

<!-- Collect the nav links, forms, and other content for toggling -->
<div class="collapse navbar-collapse col-md-8 navbar-right navbar-main-collapse">
<ul class="nav navbar-nav">
<!-- Hidden li included to remove active class from about link when scrolled up past about section -->
<li class="hidden">
<a href="./"></a>
</li>
<li class="dropdown li-lang">
<a class="dropdown-toggle" href="#" id="dropdown09" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="flag-icon flag-icon-sa"> </span> Arabic</a>
<div class="dropdown-menu" aria-labelledby="dropdown09" style="min-width: auto;">
<ul class="ul-lang" style="display: block;padding: 0px;" ><li><a class="dropdown-item" href="changelanguage.php?language=English" style="line-height: inherit;padding: 3px;white-space: nowrap;" ><span class="flag-icon flag-icon-us"> </span> English</a></li><li><a class="dropdown-item" href="changelanguage.php?language=French" style="line-height: inherit;padding: 3px;white-space: nowrap;" ><span class="flag-icon flag-icon-fr"> </span> French</a></li></ul></div></li> 
<li>
<a href='about'>إعرفنا</a>
</li> 
<li>
<a href='services'>خدمات</a>
</li> 
<li>
<a href='portfolio'>أعمالنا</a>
</li> 
<li>
<a href='contacts'>إتصل</a>
</li>
</ul>
</div>
<!-- /.navbar-collapse -->
</div>
<!-- /.container -->
</nav>

<!-- Navigation -->
<a id="menu-toggle" href="#" class="btn btn-dark btn-lg toggle"><i class="fa fa-bars"></i></a>
<nav id="sidebar-wrapper">
<ul class="sidebar-nav">
<a id="menu-close" href="#" class="btn btn-light btn-lg pull-right toggle"><i class="fa fa-times"></i></a>



<li class='sidebar-brand'>			
<a href='./' onclick=$('#menu-close').click();>
<img src ='assets/img/uploads/other/teamthe4-logo.jpg' style='height: -webkit-fill-available; border-radius: 7px;' /></a>
</li><li class="dropdown li-lang">
<a class="dropdown-toggle" href="#" id="dropdown09" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="flag-icon flag-icon-sa"> </span> Arabic</a>
<div class="dropdown-menu" aria-labelledby="dropdown09" style="min-width: auto;">
<ul class="ul-lang" style="display: block;padding: 0px;" ><li><a class="dropdown-item" href="changelanguage.php?language=English" style="line-height: inherit;padding: 3px;white-space: nowrap;" ><span class="flag-icon flag-icon-us"> </span> English</a></li><li><a class="dropdown-item" href="changelanguage.php?language=French" style="line-height: inherit;padding: 3px;white-space: nowrap;" ><span class="flag-icon flag-icon-fr"> </span> French</a></li></ul></div></li> 
<li>
<a href='about' onclick=$('#menu-close').click();>إعرفنا</a>
</li> 
<li>
<a href='services' onclick=$('#menu-close').click();>خدمات</a>
</li> 
<li>
<a href='portfolio' onclick=$('#menu-close').click();>أعمالنا</a>
</li> 
<li>
<a href='contacts' onclick=$('#menu-close').click();>إتصل</a>
</li>

</ul>
</nav>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>
$('.cd-secondary-nav .dropdown-menu').css('background-color',$('.cd-secondary-nav').css('background-color'));
</script>

	
		<div class="wrapper">
			<div id="error">
			 <h2 class='animated infinite bounce delay-2s'>Page not found .. الصفحة غير موجودة</h2>
				<h2>Error 404 - Page not found ..</h2>
				<h3>Sorry, but this page doesn't exist, or your search might lead you into this error page.</h3>
				<img src="assets/img/error.jpg" alt="Error 404 - Page not found" />
			</div>
		</div> 
		
	</section>


<script type="text/javascript">
    $(document).ready(function() {
	var doctitle= $(this).attr("title");
        $(this).attr("title", "فريق الأربعة");
    });
</script>
	
	
<!-- Footer -->
<footer class='footer-bs'>
<div class='row'>
<div class='col-md-4 col-sm-6 text-center footer-brand'>
<h3>إعرفنا</h3>

<div class='col-md-12'>				
<img src ='assets/img/uploads/other/teamthe4-logo.jpg' class='img-responsive' style='border-radius: 15px;' />
<p> </p></div><br/> 

<h4>فريق الأربعة للإتصالات وتقنية المعلومات</h4>
<i class='fa fa-home fa-fw'></i> حي الأحمدية - شارع الأمير أحمد بن عبد العزيز | 23456-3453
<ul class='list-unstyled'>
<li><i class='fa fa-map-marker fa-fw'></i> 46.615604400634766 | 24.633012771606445</li>
<li><i class='fa fa-envelope-o fa-fw'></i> <a href="/cdn-cgi/l/email-protection#21484f474e615544404c554944150f424e4c"><span class="__cf_email__" data-cfemail="5e373038311e2a3b3f332a363b6a703d3133">[email&#160;protected]</span></a></li>
<li><i class='fa fa-phone fa-fw'></i> +966 ( 0563720102 - 0548633511 )</li>

</ul>
</div>
<div class='col-md-2 col-sm-6 footer-nav'>
<h3>القائمة</h3>
<ul class='pages'>
 
<li>
<a href='about'>إعرفنا</a>
</li> 
<li>
<a href='services'>خدمات</a>
</li> 
<li>
<a href='portfolio'>أعمالنا</a>
</li> 
<li>
<a href='contacts'>إتصل</a>
</li> 
<li>
<a href='privacy'>الخصوصية</a>
</li>
</ul>				
</div>
<div class='col-md-2 col-sm-6 footer-social'>
<h3>تابعنا</h3>
<ul>
<li><a href='https://www.facebook.com/' target='_blank'> فيس بوك</a></li><li><a href='#' target='_blank'> تويتر</a></li><li><a href='#' target='_blank'> لينكد إن</a></li><li><a href='#' target='_blank'> يوت يوب</a></li>
</ul>
</div>

</div>
</footer>
<section id='the-end' class='text-center'><p>جميع الحقوق محفوظة لشركة فريق الأربعة . 2019</p></section>
<!-- ./Footer -->
	
		
	</div>
	
           
	<a id="to-top" href="#top" class="btn btn-dark btn-lg"><i class="fa fa-chevron-up fa-fw fa-1x"></i></a>
	
    <!-- jQuery -->
    <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/js/jquery.js"></script>
	<script src="assets/js/parallax.js"></script>

		
	<script src="assets/js/owl.carousel.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="assets/js/bootstrap.min.js"></script>	
	<script type="text/javascript" src="assets/js/jquery.plugin.js"></script>
    <script type="text/javascript" src="assets/js/jquery.countdown.js"></script>

		
	<script type="text/javascript" src="assets/js/resize-slider-min.js"></script>
     
<script>		
$(document).ready(function ()
{

$('#resizeSlider').resizeSlider(
{
//    'transition' : 750,
//    'speed'      : 3750,
//    'hover'      : false,
//    'aleatorio'  : false,
//    'float'      : 'right',
//    'width'      : '500px',
//    'height'     : '500px',
'image':
{
'presentation 27':
{
'landscape':
{
'url'      : 'url(assets/img/uploads/other/slide-27-ar.jpeg)',
'size'     : 'cover',
'repeat'   : 'no-repeat',
'position' : 'center bottom'
},
'portrait':
{
'url'      : 'url(assets/img/uploads/other/slide-27-ar.jpeg)',
'size'     : 'cover',
'repeat'   : 'no-repeat',
'position' : 'left center'
}
},



'presentation 28':
{
'landscape':
{
'url'      : 'url(assets/img/uploads/other/slide-28-ar.gif)',
'size'     : 'cover',
'repeat'   : 'no-repeat',
'position' : 'center bottom'
},
'portrait':
{
'url'      : 'url(assets/img/uploads/other/slide-28-ar.gif)',
'size'     : 'cover',
'repeat'   : 'no-repeat',
'position' : 'left center'
}
},



'presentation 26':
{
'landscape':
{
'url'      : 'url(assets/img/uploads/other/slide-26-ar.png)',
'size'     : 'cover',
'repeat'   : 'no-repeat',
'position' : 'center bottom'
},
'portrait':
{
'url'      : 'url(assets/img/uploads/other/slide-26-ar.png)',
'size'     : 'cover',
'repeat'   : 'no-repeat',
'position' : 'left center'
}
},



'presentation 29':
{
'landscape':
{
'url'      : 'url(assets/img/uploads/other/slide-29-ar.jpg)',
'size'     : 'cover',
'repeat'   : 'no-repeat',
'position' : 'center bottom'
},
'portrait':
{
'url'      : 'url(assets/img/uploads/other/slide-29-ar.jpg)',
'size'     : 'cover',
'repeat'   : 'no-repeat',
'position' : 'left center'
}
},



'presentation 30':
{
'landscape':
{
'url'      : 'url(assets/img/uploads/other/slide-30-ar.gif)',
'size'     : 'cover',
'repeat'   : 'no-repeat',
'position' : 'center bottom'
},
'portrait':
{
'url'      : 'url(assets/img/uploads/other/slide-30-ar.gif)',
'size'     : 'cover',
'repeat'   : 'no-repeat',
'position' : 'left center'
}
},



'presentation 31':
{
'landscape':
{
'url'      : 'url(assets/img/uploads/other/slide-31-ar.gif)',
'size'     : 'cover',
'repeat'   : 'no-repeat',
'position' : 'center bottom'
},
'portrait':
{
'url'      : 'url(assets/img/uploads/other/slide-31-ar.gif)',
'size'     : 'cover',
'repeat'   : 'no-repeat',
'position' : 'left center'
}
},



'presentation 32':
{
'landscape':
{
'url'      : 'url(assets/img/uploads/other/slide-32-ar.png)',
'size'     : 'cover',
'repeat'   : 'no-repeat',
'position' : 'center bottom'
},
'portrait':
{
'url'      : 'url(assets/img/uploads/other/slide-32-ar.png)',
'size'     : 'cover',
'repeat'   : 'no-repeat',
'position' : 'left center'
}
},



'presentation 33':
{
'landscape':
{
'url'      : 'url(assets/img/uploads/other/slide-33-ar.png)',
'size'     : 'cover',
'repeat'   : 'no-repeat',
'position' : 'center bottom'
},
'portrait':
{
'url'      : 'url(assets/img/uploads/other/slide-33-ar.png)',
'size'     : 'cover',
'repeat'   : 'no-repeat',
'position' : 'left center'
}
},



'presentation 34':
{
'landscape':
{
'url'      : 'url(assets/img/uploads/other/slide-34-ar.jpg)',
'size'     : 'cover',
'repeat'   : 'no-repeat',
'position' : 'center bottom'
},
'portrait':
{
'url'      : 'url(assets/img/uploads/other/slide-34-ar.jpg)',
'size'     : 'cover',
'repeat'   : 'no-repeat',
'position' : 'left center'
}
},


}
})
});		
</script>

    <!-- Custom Theme JavaScript -->
    <script>
    // Closes the sidebar menu
    $("#menu-close").click(function(e) {
        e.preventDefault();
        $("#sidebar-wrapper").toggleClass("active");
    });
    // Opens the sidebar menu
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#sidebar-wrapper").toggleClass("active");
    });
    // Scrolls to the selected menu item on the page
    $(function() {
        $('a[href*=#]:not([href=#],[data-toggle],[data-target],[data-slide])').click(function() {
            if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') || location.hostname == this.hostname) {
                var target = $(this.hash);
                target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
                if (target.length) {
                    $('html,body').animate({
                        scrollTop: target.offset().top
                    }, 1000);
                    return false;
                }
            }
        });
    });
	 //#to-top button appears after scrolling
    var fixed = false;
    $(document).scroll(function() {
        if ($(this).scrollTop() > 250) {
            if (!fixed) {
                fixed = true;
                // $('#to-top').css({position:'fixed', display:'block'});
                $('#to-top').show("slow", function() {
                    $('#to-top').css({
                        position: 'fixed',
                        display: 'block'
                    });
                });
            }
        } else {
            if (fixed) {
                fixed = false;
                $('#to-top').hide("slow", function() {
                    $('#to-top').css({
                        display: 'none'
                    });
                });
            }
        }
    });
	$(document).ready(function noscroll() {
		
    // Disable Google Maps scrolling
    // See http://stackoverflow.com/a/25904582/1607849
    // Disable scroll zooming and bind back the click event
    var onMapMouseleaveHandler = function(event) {
        var that = $(this);
        that.on('click', onMapClickHandler);
        that.off('mouseleave', onMapMouseleaveHandler);
        that.find('span').css("pointer-events", "none");
    }
    var onMapClickHandler = function(event) {
            var that = $(this);
            // Disable the click handler until the user leaves the map area
            that.off('click', onMapClickHandler);
            // Enable scrolling zoom
            that.find('span').css("pointer-events", "auto");
            // Handle the mouse leave event
            that.on('mouseleave', onMapMouseleaveHandler);
        }
        // Enable map zooming with mouse scroll when the user clicks the map
    $('.map').on('click', onMapClickHandler);

		
	});
   
	$(document).ready(function myFunction() {
		var myVar = setTimeout(showPage, 2000);
		
	});
	function showPage() {
		$('#preloader').css('display','none');
		$('#spinner').css('display','none');
	}

</script>

		<script src="assets/js/validator.js"></script>
        <script src="assets/js/contact.js"></script>
		
		<script src="assets/js/isotope.min.js"></script>
		<script src="assets/js/jquery.fancybox.pack.js"></script>
	
	<script>
		jQuery(document).ready(function($) {
			"use strict";
			//  TESTIMONIALS CAROUSEL HOOK
			$('#customers-testimonials').owlCarousel({
				loop: true,
				center: true,
				items: 3,
				margin: 0,
				autoplay: true,
				dots:true,
				autoplayTimeout: 8500,
				smartSpeed: 450,
				responsive: {
				  0: {
					items: 1
				  },
				  768: {
					items: 2
				  },
				  1170: {
					items: 3
				  }
				}
			});
			//  Clients CAROUSEL HOOK
			$("#brand-carousel").owlCarousel({

				loop: true,
				items: 6,
				margin: 0,
				autoplay: true,
				dots:true,
				autoplayTimeout: 4500,
				smartSpeed: 450,
				responsive: {
				  0: {
					items: 1
				  },
				  768: {
					items: 3
				  },
				  1199: {
					items: 5
				  }
				}

			});
		
		});
	</script>
	<script src="assets/js/classie.js"></script>
	<script>
			(function() {
				// trim polyfill : https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/Trim
				if (!String.prototype.trim) {
					(function() {
						// Make sure we trim BOM and NBSP
						var rtrim = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g;
						String.prototype.trim = function() {
							return this.replace(rtrim, '');
						};
					})();
				}

				[].slice.call( document.querySelectorAll( 'input.input__field' ) ).forEach( function( inputEl ) {
					// in case the input is already filled..
					if( inputEl.value.trim() !== '' ) {
						classie.add( inputEl.parentNode, 'input--filled' );
					}

					// events:
					inputEl.addEventListener( 'focus', onInputFocus );
					inputEl.addEventListener( 'blur', onInputBlur );
				} );

				function onInputFocus( ev ) {
					classie.add( ev.target.parentNode, 'input--filled' );
				}

				function onInputBlur( ev ) {
					if( ev.target.value.trim() === '' ) {
						classie.remove( ev.target.parentNode, 'input--filled' );
					}
				}
			})();
		</script>	
		
		
	<!-- Fixed top menu script -->
	<script>
		$(document).ready(function () {
			// jQuery to collapse the navbar on scroll
			function collapseNavbar() {
				if ($(".navbar").offset().top > 50) {
					$(".navbar-fixed-top").addClass("top-nav-collapse");
				} else {
					$(".navbar-fixed-top").removeClass("top-nav-collapse");
				}
			}

			$(window).scroll(collapseNavbar);
			$(document).ready(collapseNavbar);

			// Closes the Responsive Menu on Menu Item Click
			$('.navbar-collapse ul li a').click(function() {
if($(this).data('toggle') != 'dropdown' ){
	$(".navbar-collapse").collapse('hide'); 
	}
});
		});(jQuery);
	</script>
	
	<!-- Slick Slider -->
	<script src="assets/js/slick.js"></script>
	<script>	
		$(document).ready(function () {
		  
		  $(".Modern-Slider").slick({
			autoplay:true,
			autoplaySpeed:10000,
			speed:600,
			slidesToShow:1,
			slidesToScroll:1,
			pauseOnHover:false,
			dots:true,
			pauseOnDotsHover:true,
			cssEase: 'cubic-bezier(0.7, 0, 0.3, 1)',
			fade:true,
			draggable:true,
			prevArrow:'<button class="PrevArrow"></button>',
			nextArrow:'<button class="NextArrow"></button>', 
		  });
		  
		});(jQuery);
	</script>
	
	<script>
			// For Demo purposes only (show hover effect on mobile devices)
			[].slice.call( document.querySelectorAll('a[href="#"') ).forEach( function(el) {
				el.addEventListener( 'click', function(ev) { ev.preventDefault(); } );
			} );
		
		

		</script>
		
</body>

</html><script type='text/javascript'>swal('عفوا !', 'هناك خطأ ما', 'error');</script><meta http-equiv="refresh" content="5; http://teamthe4.com">